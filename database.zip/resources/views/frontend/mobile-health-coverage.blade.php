@extends('frontend.layouts.master')
@section('meta_title')
@endsection
@section('title')
Mobile Health Coverage
@endsection
@push('styles')
@endpush

@section('content')
<section class="career">
    <div class="container">
      <div class="wrapper">
        <div class="content">
          <h1>We're Coming Soon</h1>
        </div>
      </div>
    </div>
  </section>
@endsection

@push('scripts')
@endpush
