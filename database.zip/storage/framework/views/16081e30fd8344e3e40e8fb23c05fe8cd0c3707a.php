<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul class="sidebar-vertical">
                <li class="menu-title">
                    <span>Main</span>
                </li>
                <li class="<?php echo e(Request::is('admin/dashboard*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" ><i class="la la-dashboard"></i> <span>Dashboard</span></a>                 
                </li>

                <li class="submenu">
                    <a href="#" class="<?php echo e(Request::is('admin/profile*') || Request::is('admin/password*') || Request::is('admin/detail*') ? 'active' : ' '); ?>"><i class="la la-user-cog"></i> <span>Manage Account </span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class="<?php echo e(Request::is('admin/profile*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('admin.profile')); ?>">My Profile</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/password*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('admin.password')); ?>">Change Password</a>
                        </li>                
                    </ul>
                </li>
                <li class="menu-title">
                    <span>Speciality Management</span>
                </li>
                <li class="<?php echo e(Request::is('admin/specializations*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('specializations.index')); ?>" ><i class="	la la-heart"></i> <span>Specialization</span></a>                 
                </li>
                <li class="<?php echo e(Request::is('admin/symptoms*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('symptoms.index')); ?>" ><i class="	fa fa-stethoscope"></i> <span>Symptoms</span></a>                 
                </li>

                <li class="menu-title">
                    <span>User Management</span>
                </li>
                <li class="<?php echo e(Request::is('admin/patients*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('patients.index')); ?>" ><i class="fa fa-wheelchair"></i> <span>Manage Patients</span></a>                 
                </li>

                <li class="<?php echo e(Request::is('admin/doctors*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('doctors.index')); ?>" ><i class="fas fa-user-md"></i> <span>Manage Doctors</span></a>                 
                </li>

                <li class="menu-title">
                    <span>Plan Management</span>
                </li>
                <li class="<?php echo e(Request::is('admin/plans*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('plans.index')); ?>" ><i class="la la-address-card"></i> <span>Membership Plans</span></a>                 
                </li>

                <li class="menu-title">
                    <span>Others</span>
                </li>
                <li class="submenu">
                    <a href="#" class="<?php echo e(Request::is('admin/blogs*') ? 'active' : ' '); ?>"><i class="la la-blog"></i> <span>Blogs</span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class="<?php echo e(Request::is('admin/blogs/categories*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('blogs.categories.index')); ?>">Category</a>
                        </li>
                        <li class="<?php echo e(Request::is('admin/blogs') | Request::is('admin/blogs/create') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('blogs.index')); ?>">Details</a>
                        </li>                
                    </ul>
                </li>
                <li class="<?php echo e(Request::is('admin/contact-us*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('contact-us.index')); ?>" ><i class="la la-phone"></i> <span>Contact Us</span></a>                 
                </li>
                <li class="<?php echo e(Request::is('admin/newsletters*') ? 'active' : ' '); ?>">
                    <a href="<?php echo e(route('newsletters.index')); ?>" ><i class="la la-paper-plane"></i> <span>Newsletter</span></a>                 
                </li>
                <li class="submenu">
                    <a href="#" class="<?php echo e(Request::is('admin/cms*') ? 'active' : ' '); ?>"><i class="la la-cog"></i> <span>Settings</span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">
                        <li class="<?php echo e(Request::is('admin/cms/qna*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.qna.index')); ?>">QNA Page</a>
                        </li>         
                        <li class="<?php echo e(Request::is('admin/cms/contact-us*') ? 'active' : ' '); ?>">
                            <a href="<?php echo e(route('cms.contact-us.index')); ?>">Contact Us Page</a>
                        </li>     
                    </ul>
                </li>
            </ul> 
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>