
<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Q&A / Blogs
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="inr-bnr">
        <div class="inr-bnr-img">
            <img src="<?php echo e(asset('frontend_assets/images/blog-bg.jpg')); ?>" alt="" />
            <div class="inr-bnr-text">
                <h1>Q&A / Blogs</h1>
            </div>
        </div>
    </section>
    <section class="q-acc">
        <div class="container">
            <div class="head-1 h-b text-center" data-aos="fade-up" data-aos-duration="1000">
                <h2>Frequently <span>Asked Questions</span></h2>
                <p>We have curated a list of general FAQs covering all your queries.</p>
            </div>
            <div class="q-acc" data-aos="fade-up" data-aos-duration="1000">
                <div class="accordion" id="accordionExample">
                    <div class="row justify-content-between">
                        <?php $__currentLoopData = $qnas->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-6">
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button <?php if($key==0): ?> <?php else: ?> collapsed <?php endif; ?>" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse<?php echo e($key); ?>" aria-expanded="true"
                                        aria-controls="collapse<?php echo e($key); ?>">
                                        <?php echo e($key+1); ?>. <?php echo e($item->question); ?>

                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($key); ?>" class="accordion-collapse collapse <?php if($key==0): ?> show <?php endif; ?>"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <?php echo $item->answer; ?>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
    
                    </div>
                </div>
            </div>
    </section>
    <section class="blog-inr">
        <div class="container">
            <div class="blog-inr-wrap">
                <div class="row justify-content-between">
                    <div class="col-xl-9 col-12" id="search-result">
                        <?php echo $__env->make('frontend.search-result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-xl-3 col-12">
                        <?php if(count($blogsCategories) > 0): ?>
                            <div class="cat-div">
                                <div class="cat-box">
                                    <h4>CATEGORIES</h4>
                                    <ul class="cat-list">
                                        <?php $__currentLoopData = $blogsCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a
                                                    href="<?php echo e(route('blogs', ['slug' => $category['slug']])); ?>"><?php echo e($category['name']); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="cat-div">
                            <div class="cat-box">
                                <h4>SEARCH</h4>
                                <div class="search-form">
                                    <form action="javascript:void(0);">
                                        <input type="text" placeholder="search here" name="search" id="search-blog" data-route="<?php echo e(route('blogs.search')); ?>" />
                                        <button type="submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php if(count($lastBlogs) > 0): ?>
                            <div class="cat-div">
                                <div class="cat-box">
                                    <h4>LAST 10 POST</h4>
                                    <ul class="cat-list">
                                        <?php $__currentLoopData = $lastBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a
                                                    href="<?php echo e(route('blogs.details', ['category_slug' => $lastBlog['category']['slug'], 'blog_slug' => $lastBlog['slug']])); ?>">
                                                    <?php echo e($lastBlog['title']); ?>

                                                </a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                </div>
                            </div>
                        <?php endif; ?>
                        
                    </div>
                </div>


                <div class="pagi_1">
                    <nav aria-label="Page navigation example">
                        <?php echo e($blogs->links()); ?>                                                                                                         
                    </nav>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
       $('#search-blog').keyup(function() {
           var search = $(this).val();
              var route = $(this).data('route');
               $.ajax({
                   url: route,
                   method: "POST",
                   data: {
                       "_token": "<?php echo e(csrf_token()); ?>",
                       "search": search
                   },
                   success: function(response) {
                       $('#search-result').html(response.view);
                   }
               });
           
       });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/frontend/blogs.blade.php ENDPATH**/ ?>