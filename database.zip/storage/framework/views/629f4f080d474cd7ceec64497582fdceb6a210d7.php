
<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Membership Plans
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="inr-bnr">
        <div class="inr-bnr-img">
            <img src="<?php echo e(('frontend_assets/images/blog-bg.jpg')); ?>" alt="" />
            <div class="inr-bnr-text">
                <h1>Membership</h1>
            </div>
        </div>
    </section>
    <section class="mem-sec">
        <div class="container">
            <div class="mem-sec-wrap">
                <div class="row justify-content-center align-items-center">
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-6 col-12">
                        <div class="mem-box-wrap">
                            <div class="mem-box <?php if($key == 1): ?> mem-box-2 <?php endif; ?> <?php if($key == 2): ?> mem-box-3 <?php endif; ?>" >
                                <h3><?php echo e($plan['plan_name']); ?></h3>
                            </div>
                            <div class="price-box">
                                <h2><span>USD</span>$<?php echo e($plan['plan_price']); ?><span>(<?php echo e($plan['plan_type']); ?>)</span></h2>
                            </div>
                            <div class="mem-list">
                                <ul>
                                    <?php $__currentLoopData = $plan->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($specification['specification_name']); ?></li>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <div class="main-btn pt-4">
                                    <a href="#" tabindex="0"><span>buy now</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/frontend/membership-plans.blade.php ENDPATH**/ ?>