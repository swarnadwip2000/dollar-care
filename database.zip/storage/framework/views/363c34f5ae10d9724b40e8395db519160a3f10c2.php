
<?php $__env->startSection('title'); ?>
    <?php echo e(env('APP_NAME')); ?> | Create Doctor
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Create</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('doctors.index')); ?>">Doctors</a></li>
                            <li class="breadcrumb-item active">Create Doctor</li>
                        </ul>
                    </div>
                    <div class="col-auto float-end ms-auto">
                        
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <div class="row">
                            <div class="col-xl-12 mx-auto">
                                <h6 class="mb-0 text-uppercase">Create A Doctor</h6>
                                <hr>
                                <div class="card border-0 border-4">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('doctors.store')); ?>" method="post"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="border p-4 rounded">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Name <span
                                                                style="color: red;">*</span></label>
                                                        <input type="text" name="name" id=""
                                                            class="form-control" value="<?php echo e(old('name')); ?>"
                                                            placeholder="Enter Doctor Name">
                                                        <?php if($errors->has('name')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('name')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Email <span
                                                                style="color: red;">*</span></label>
                                                        <input type="text" name="email" id=""
                                                            class="form-control" value="<?php echo e(old('email')); ?>"
                                                            placeholder="Enter Doctor Email">
                                                        <?php if($errors->has('email')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('email')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Phone <span
                                                                style="color: red;">*</span></label>
                                                        <input type="text" name="phone" id=""
                                                            class="form-control" value="<?php echo e(old('phone')); ?>"
                                                            placeholder="Enter Phone Number">
                                                        <?php if($errors->has('phone')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('phone')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label">
                                                            Specialization <span style="color: red;">*</span></label>
                                                        <select name="specialization_id[]" id="specialization_id" class="form-control" multiple>
                                                            <option value="">Select Specialization</option>
                                                            <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($specialization['id']); ?>"><?php echo e($specialization['name']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php if($errors->has('specialization_id')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('specialization_id')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Year of
                                                            Experience <span style="color: red;">*</span></label>
                                                        <input type="text" name="year_of_experience" id=""
                                                            class="form-control" value="<?php echo e(old('year_of_experience')); ?>"
                                                            placeholder="Enter year of experience">
                                                        <?php if($errors->has('year_of_experience')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('year_of_experience')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="" class="col-form-label">Gender<span
                                                                class="text-danger">*</span> </label>
                                                        <div class="display-between">
                                                            <span for="" class="radio-gender">Male </span> <input
                                                                type="radio" class="gender" name="gender" id="gender"
                                                                value="Male" checked>
                                                            <span class="radio-gender">Female </span> <input type="radio"
                                                                class="gender" name="gender" id="gender" value="Female">
                                                            <span class="radio-gender">Other </span> <input type="radio"
                                                                class="gender" name="gender" id="gender"
                                                                value="Other">
                                                        </div>
                                                        <?php if($errors->has('gender')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('gender')); ?></div>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Location (
                                                            City,State,Country,Pincode )
                                                            <span style="color: red;">*</span></label>
                                                        <input type="text" name="location" id="location"
                                                            class="form-control" value="<?php echo e(old('location')); ?>"
                                                            placeholder="Location">
                                                        <?php if($errors->has('location')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('location')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Status
                                                            <span style="color: red;">*</span></label>
                                                        <select name="status" id="" class="form-control">
                                                            <option value="">Select a Status</option>
                                                            <option value="1">Active</option>
                                                            <option value="0">Inactive</option>
                                                        </select>
                                                        <?php if($errors->has('status')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('status')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Password
                                                            <span style="color: red;">*</span></label>
                                                        <input type="password" name="password" id=""
                                                            class="form-control" value="<?php echo e(old('password')); ?>"
                                                            placeholder="Enter pasword">
                                                        <?php if($errors->has('password')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('password')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Confirm
                                                            Password <span style="color: red;">*</span></label>
                                                        <input type="password" name="confirm_password" id=""
                                                            class="form-control" value="<?php echo e(old('confirm_password')); ?>">
                                                        <?php if($errors->has('confirm_password')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('confirm_password')); ?></div>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Profile
                                                            Picture <span style="color: red;">*</span></label>
                                                        <input type="file" name="profile_picture" id=""
                                                            class="form-control" value="<?php echo e(old('profile_picture')); ?>">
                                                        <?php if($errors->has('profile_picture')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('profile_picture')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="row" style="margin-top: 20px; float: left;">
                                                        <div class="col-sm-9">
                                                            <button type="submit"
                                                                class="btn px-5 submit-btn">Create</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#specialization_id').select2();
        });
    </script>   
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/admin/doctor/create.blade.php ENDPATH**/ ?>