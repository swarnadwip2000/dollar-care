
<?php $__env->startSection('meta_title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Telehealth
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="career">
    <div class="container">
      <div class="wrapper">
        <div class="content">
          <h1>We're Coming Soon</h1>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/frontend/telehealth.blade.php ENDPATH**/ ?>