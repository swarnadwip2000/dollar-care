
<?php $__env->startSection('title'); ?>
    <?php echo e(env('APP_NAME')); ?> | Edit Specializations Details
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">

        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Edit Details</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('specializations.index')); ?>">Specializations</a>
                            </li>
                            <li class="breadcrumb-item active">Edit Specializations Details</li>
                        </ul>
                    </div>
                    <div class="col-auto float-end ms-auto">
                        
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <div class="row">
                            <div class="col-xl-12 mx-auto">
                                <h6 class="mb-0 text-uppercase">Edit A Specializations</h6>
                                <hr>
                                <div class="card border-0 border-4">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('specializations.update', $specialization->id)); ?>"
                                            method="POST" enctype="multipart/form-data">
                                            <?php echo method_field('PUT'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($specialization->id); ?>">
                                            <div class="border p-4 rounded">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label">
                                                            Specialization Name <span style="color: red;">*</span></label>
                                                        <input type="text" name="name" id=""
                                                            class="form-control" value="<?php echo e($specialization['name']); ?>"
                                                            placeholder="Enter Specialization Name">
                                                        <?php if($errors->has('name')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('name')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label">
                                                            Specialization Slug <span style="color: red;">*</span></label>
                                                        <input type="text" name="slug" id=""
                                                            class="form-control" value="<?php echo e($specialization['slug']); ?>"
                                                            placeholder="Enter Specialization Slug">
                                                        <?php if($errors->has('slug')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('slug')); ?></div>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Status
                                                            <span style="color: red;">*</span></label>
                                                        <select name="status" id="" class="form-control">
                                                            <option value="">Select a Status</option>
                                                            <option value="1"
                                                                <?php if($specialization['status'] == 1): ?> selected="" <?php endif; ?>>Active
                                                            </option>
                                                            <option value="0"
                                                                <?php if($specialization['status'] == 0): ?> selected="" <?php endif; ?>>
                                                                Inactive</option>
                                                        </select>
                                                        <?php if($errors->has('status')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('status')); ?></div>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label for="inputEnterYourName" class="col-form-label"> Image
                                                        </label>
                                                        <input type="file" name="image" id=""
                                                            class="form-control" value="<?php echo e($specialization['image']); ?>">
                                                        <?php if($errors->has('image')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('image')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                    </div>
                                                    <?php if($specialization['image']): ?>
                                                        <div class="col-md-6">
                                                            <label for="inputEnterYourName" class="col-form-label">View
                                                                Profile Picture </label>
                                                            <br>
                                                            <img src="<?php echo e(Storage::url($specialization['image'])); ?>"
                                                                alt="" class="img-design"
                                                                style="height:50px; width: 50px;">
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="col-md-12">
                                                        <label for="inputEnterYourName" class="col-form-label"> Description
                                                            <span style="color: red;">*</span></label>
                                                        <textarea name="description" id="" cols="30" rows="10" class="form-control"><?php echo e($specialization['description']); ?></textarea>
                                                        <?php if($errors->has('description')): ?>
                                                            <div class="error" style="color:red;">
                                                                <?php echo e($errors->first('description')); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="row" style="margin-top: 20px; float: left;">
                                                        <div class="col-sm-9">
                                                            <button type="submit"
                                                                class="btn px-5 submit-btn">Update</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#specialization_id').select2();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/admin/specializations/edit.blade.php ENDPATH**/ ?>