<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="robots" content="noindex, nofollow">
    <!-- provide the csrf token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('admin_assets/img/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/plugins/fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/line-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/material.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/line-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/plugins/morris/morris.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/bootstrap-datetimepicker.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <style>
        .error {
            color: red;
        }
    </style>
</head>

<body>
    <!--header-->
    <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--end header-->
    <!--sidebar-wrapper-->
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end sidebar-wrapper-->

    <!--page-wrapper-->
    <?php echo $__env->yieldContent('content'); ?>

    <!--end page-wrapper-->

    <!--footer -->
    <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- end footer -->

</body>
<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="<?php echo e(asset('admin_assets/js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/js/jquery.slimscroll.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/plugins/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/plugins/raphael/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/chart.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/greedynav.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/js/layout.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/theme-settings.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/app.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>

<script>
    <?php if(Session::has('message')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.success("<?php echo e(session('message')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(Session::has('info')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>
</script>
<script>
    $(document).ready(function() {
        toastr.options = {
            // 'closeButton': true,
            // 'debug': false,
            // 'newestOnTop': false,
            // 'progressBar': false,
            'positionClass': 'toast-top-center',
            // 'preventDuplicates': false,
            'showDuration': '10',
            'hideDuration': '10',
            'timeOut': '800',
            'extendedTimeOut': '800',
            // 'showEasing': 'swing',
            // 'hideEasing': 'linear',
            // 'showMethod': 'fadeIn',
            // 'hideMethod': 'fadeOut',
        }
    });
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>

</html>
<?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>