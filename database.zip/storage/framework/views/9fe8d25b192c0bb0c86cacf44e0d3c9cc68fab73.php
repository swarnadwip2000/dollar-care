<?php if(count($blogs) > 0): ?>
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-box-1">
            <div class="blog-inr-img">
                <img src="<?php echo e(Storage::url($blog['image'])); ?>" alt="" />
            </div>
            <div class="blog-text">
                <div class="date-box d-flex align-items-center justify-content-end">
                    <div class="bl-date-img">
                        <img src="<?php echo e(asset('frontend_assets/images/date.png')); ?>" alt="" />
                    </div>
                    <div class="bl-date">
                        <h4><?php echo e(date("d M' Y", strtotime($blog['created_at']))); ?></h4>
                    </div>
                </div>
                <div class="head-1 h-b pb-3">
                    <h2><?php echo e($blog['title']); ?></h2>
                </div>
                <div class="para p-b">
                    <p>
                        <?php echo substr($blog['content'], 0, 250); ?>

                    </p>
                </div>
                <div class="main-btn pt-4">
                    <a href="<?php echo e(route('blogs.details', ['category_slug' => $blog['category']['slug'], 'blog_slug' => $blog['slug']])); ?>"
                        tabindex="0"><span>read more</span><span class="btn-arw"><i
                                class="fa-solid fa-arrow-right"></i></span></a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div>
        <h2>No blogs found</h2>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\dollar_care\resources\views/frontend/search-result.blade.php ENDPATH**/ ?>